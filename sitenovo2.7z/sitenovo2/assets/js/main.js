document.addEventListener('DOMContentLoaded', function () {
    showUserInfo();
    loadDashboardContent();
  });
  