// Função para navegar entre seções do dashboard
function navigate(section) {
  const content = document.getElementById('content');
  const menuItems = document.querySelectorAll('.menu-item');
  
  menuItems.forEach(item => item.classList.remove('active'));
  document.querySelector(`.menu-item[onclick="navigate('${section}')"]`).classList.add('active');
  
  if (section === 'home') {
    content.innerHTML = `
      <div class="home-content">
        <h1>Sistema de Demandas Descomplica Uniamérica</h1>
        <p>Bem-vindo ao sistema que simplifica o gerenciamento de demandas de projetos acadêmicos e profissionais.</p>
        <div class="navigation-buttons">
          <button onclick="navigate('demands')">Ver Demandas</button>
          <button onclick="navigate('profile')">Acessar Perfil</button>
          <button onclick="navigate('settings')">Configurações</button>
        </div>
      </div>
    `;
  } else if (section === 'profile') {
    renderProfile(content);
  } else if (section === 'demands') {
    renderDemands(content);
  } else if (section === 'settings') {
    renderSettings(content);
  }
}

// Renderizar perfil do usuário
function renderProfile(content) {
  content.innerHTML = `
    <div class="profile">
      <h2>Perfil do Usuário</h2>
      <div class="profile-icon">
        <img id="profile-picture" src="assets/images/default-profile.png" alt="Foto de Perfil">
        <button onclick="updateProfilePicture()">Atualizar Foto</button>
        <input type="file" id="fileInput" style="display:none" accept="image/*" onchange="handleProfilePictureUpload(event)">
      </div>
    </div>
  `;
}

// Renderizar configurações
function renderSettings(content) {
  content.innerHTML = `
    <h2>Configurações</h2>
    <button onclick="toggleDarkMode()">Ativar/Desativar Dark Mode</button>
    <button onclick="logout()">Sair</button>
  `;
}

// Renderizar demandas
function renderDemands(content) {
  content.innerHTML = `
    <h2>Demandas</h2>
    <div class="demands-container">
      ${createDemandCard('Título da Demanda 1', 'Descrição breve da demanda...', 'assets/images/demanda1.jpg')}
      ${createDemandCard('Título da Demanda 2', 'Outra descrição curta...', 'assets/images/demanda2.jpg')}
      ${createDemandCard('Título da Demanda 3', 'Mais uma breve descrição...', 'assets/images/demanda3.jpg')}
    </div>
    <div class="demand-actions">
      <button onclick="navigateToTrack()">Acompanhar Projetos</button>
      <button onclick="navigateToRegisterDemand()">Registrar Demanda</button>
    </div>
  `;
}

// Renderizar formulário para reivindicar demanda
function renderDemandForm(demandTitle) {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="demand-popup">
      <h2>Reivindicar Demanda</h2>
      <p><strong>Demanda:</strong> ${demandTitle}</p>
      <form id="claim-form">
        <label for="name">Nome:</label>
        <input type="text" id="name" placeholder="Seu nome" required>
        
        <label for="class">Turma e Turno:</label>
        <input type="text" id="class" placeholder="Ex: 3º B - Noturno" required>
        
        <label for="group">Nome dos Colegas de Grupo:</label>
        <textarea id="group" rows="2" placeholder="Digite os nomes" required></textarea>
        
        <label for="email">Email:</label>
        <input type="email" id="email" placeholder="Digite seu email" required>
        
        <button type="button" onclick="submitClaim('${demandTitle}')">Reivindicar</button>
        <button type="button" onclick="navigate('demands')">Cancelar</button>
      </form>
    </div>
  `;
}

// Submeter reivindicação
function submitClaim(demandTitle) {
  const name = document.getElementById('name').value.trim();
  const classInfo = document.getElementById('class').value.trim();
  const group = document.getElementById('group').value.trim();
  const email = document.getElementById('email').value.trim();

  if (!name || !classInfo || !group || !email) {
    alert("Por favor, preencha todos os campos antes de reivindicar.");
    return;
  }

  // Enviar dados via webhook do Discord
  const webhookUrl = 'https://discord.com/api/webhooks/1110038333977018448/PvuV9G--OMRGGwWiDpmbJ8eyyNmBmV80SmJzvD2y3jr3ywmNnf8WsmYGKEbQGqigzqFY';
  const payload = {
    content: `Nova reivindicação de demanda: ${demandTitle}
    Nome: ${name}
    Turma e Turno: ${classInfo}
    Grupo: ${group}
    Email: ${email}`
  };

  fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(() => {
    alert("Reivindicação enviada com sucesso!");
    // Remover a demanda reivindicada
    removeDemand(demandTitle);
    navigate('demands');
  }).catch(error => {
    console.error("Erro ao enviar webhook:", error);
    alert("Ocorreu um erro ao reivindicar a demanda.");
  });
}

// Função para criar cartões de demanda
function createDemandCard(title, description, imageUrl) {
  return `
    <div class="demand-card">
      <img src="${imageUrl}" alt="Imagem da Demanda">
      <h3>${title}</h3>
      <p>${description}</p>
      <button onclick="renderDemandForm('${title}')">Reivindicar</button>
    </div>
  `;
}

// Remover demanda após ser reivindicada
function removeDemand(title) {
  const demands = document.querySelectorAll('.demand-card');
  demands.forEach(demand => {
    if (demand.querySelector('h3').textContent === title) {
      demand.remove();
    }
  });
}

// Navegar para acompanhamento de projetos
function navigateToTrack() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <h2>Acompanhamento de Projetos</h2>
    <div class="track-project">
      <p><strong>Demanda:</strong> Título da Demanda 1</p>
      <p><strong>Status:</strong> Em progresso</p>
      <p><strong>Prazo:</strong> 30/12/2024</p>
      <p><strong>Responsáveis:</strong> Grupo X</p>
      <p><strong>Última atualização:</strong> Tarefa Y foi concluída.</p>
      <button onclick="navigate('demands')">Voltar</button>
    </div>
  `;
}

// Navegar para registro de demandas
function navigateToRegisterDemand() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <h2>Registrar Nova Demanda</h2>
    <form id="register-demand-form" class="register-demand-form">
      <label for="demandTitle">Título da Demanda:</label>
      <input type="text" id="demandTitle" placeholder="Digite o título da demanda" required>
      
      <label for="demandDescription">Descrição:</label>
      <textarea id="demandDescription" rows="4" placeholder="Descreva a demanda" required></textarea>
      
      <label for="demandDeadline">Prazo:</label>
      <input type="date" id="demandDeadline" required>
      
      <label for="demandImage">Imagem da Demanda:</label>
      <input type="file" id="demandImage" accept="image/*">
      
      <button type="submit">Registrar</button>
      <button type="button" onclick="navigate('demands')">Cancelar</button>
    </form>
  `;
}
